import React, { useState } from 'react';
import InputMask from 'react-input-mask';
import './line.css';

function Line() {
    // const [nome, setNome] = useState();
    // const [nome, setNome] = useState();
    // const [nome, setNome] = useState();
    const InputCpf = (props) => (
        <InputMask mask="999.999.999-99" className='form-control' maskChar='' value={props.value} placeholder='___.___.___-__' onChange={props.onChange} />
    );

    return (
        <tr>
            <th><input className='form-control'type='checkbox' /></th>
            <td><input className='form-control'type='text' placeholder='Diego' /></td>
            <td><input className='form-control' type='number' placeholder='24' /></td>
            <td>
                <select className="form-control">
                    <option disabled selected>Selecione</option>
                    <option>Solteiro</option>
                    <option>Casado</option>
                    <option>Separado</option>
                    <option>Divorciado</option>
                    <option>Viúvo</option>
                </select>
            </td>
            <td><InputCpf /></td>
            <td><input className='form-control' type='text' placeholder='São Paulo'/></td>
            <td>
                <select className='form-control' id="estado" name="estado">
                    <option disabled selected>UF</option>
                    <option>SP</option>
                    <option>AC</option>
                    <option>AL</option>
                    <option>AP</option>
                    <option>AM</option>
                    <option>BA</option>
                    <option>CE</option>
                    <option>DF</option>
                    <option>ES</option>
                    <option>GO</option>
                    <option>MA</option>
                    <option>MT</option>
                    <option>MS</option>
                    <option>MG</option>
                    <option>PA</option>
                    <option>PB</option>
                    <option>PR</option>
                    <option>PR</option>
                    <option>PI</option>
                    <option>RJ</option>
                    <option>RN</option>
                    <option>RS</option>
                    <option>RO</option>
                    <option>RR</option>
                    <option>SC</option>
                    <option>SP</option>
                    <option>SE</option>
                    <option>TO</option>
                </select>
            </td>
        </tr>
    );
}

export default Line;